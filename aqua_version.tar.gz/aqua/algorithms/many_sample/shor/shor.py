# -*- coding: utf-8 -*-

# Copyright 2018 IBM.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# =============================================================================
"""
The Quantum Dynamics algorithm.
"""

import logging, math

from qiskit import QuantumRegister, ClassicalRegister, QuantumCircuit
from qiskit.aqua.algorithms import QuantumAlgorithm
from qiskit.aqua import AquaError, Pluggable, PluggableType, get_pluggable_class
from qiskit import BasicAer, execute
from qiskit.tools.visualization import plot_histogram, circuit_drawer
import numpy as np


logger = logging.getLogger(__name__)


class SHOR(QuantumAlgorithm):
    """
    The SHOR algorithm.
    """

    PROP_OPERATOR_MODE = 'operator_mode'
    PROP_NUM_EVAL = 'num_to_evaluate'
    PROP_NUM_A = 'num_a'
    #PROP_EXPANSION_MODE = 'expansion_mode'
    #PROP_EXPANSION_ORDER = 'expansion_order'

    CONFIGURATION = {
        'name': 'SHOR',
        'description': 'Shor Factorization Algorithm',
        'input_schema': {
            '$schema': 'http://json-schema.org/schema#',
            'id': 'SHOR_schema',
            'type': 'object',
            'properties': {
                #PROP_OPERATOR_MODE: {
                #    'type': 'string',
                #    'default': 'normal',
                #    'oneOf': [
                #        {'enum': [
                #            'normal',
                #            'fixed'
                #        ]}
                #    ]
                #},
                #PROP_OPERATOR_MODE: {
                #    'type': 'string',
                #    'default': 'paulis',
                #    'oneOf': [
                #        {'enum': [
                #            'paulis',
                #            'grouped_paulis',
                #            'matrix'
                #        ]}
                #    ]
                #},
                PROP_NUM_EVAL: {
                    'type': 'integer',
                    'default': 15,
                    'minimum': 15
                },
                PROP_NUM_A: {
                    'type': 'integer',
                    'default': 2,
                    'minimum': 2
                },
                #PROP_EXPANSION_MODE: {
                #    'type': 'string',
                #    'default': 'trotter',
                #    'oneOf': [
                #        {'enum': [
                #            'trotter',
                #            'suzuki'
                #        ]}
                #    ]
                #},
                #PROP_EXPANSION_ORDER: {
                #    'type': 'integer',
                #    'default': 1,
                #    'minimum': 1
                #}
            },
            'additionalProperties': False
        },
        'problems': ['shor'],
        'depends': [
            {'pluggable_type': 'initial_state',
             'default': {
                     'name': 'ZERO'
                }
             },
        ],
    }

    def __init__(self,initial_state,operator_mode='normal', num_to_evaluate=15, num_a=1):
        self.validate(locals())
        super().__init__()
        #self._operator = operator
        self._operator_mode = operator_mode
        self._initial_state = initial_state
        self._num_to_evaluate = num_to_evaluate
        self._num_a = num_a
        #self._num_time_slices = num_time_slices
        #self._expansion_mode = expansion_mode
        #self._expansion_order = expansion_order
        self._ret = {}

    @classmethod
    def init_params(cls, params, algo_input):
        """
        Initialize via parameters dictionary and algorithm input instance
        Args:
            params: parameters dictionary
            algo_input: EnergyInput instance
        """
        if algo_input is None:
            raise AquaError("EnergyInput instance is required.")

        # For getting the extra operator, caller has to do something like: algo_input.add_aux_op(evo_op)
        #operator = algo_input.qubit_op
        #aux_ops = algo_input.aux_ops
        #if aux_ops is None or len(aux_ops) != 1:
        #    raise AquaError("EnergyInput, a single aux op is required for evaluation.")
        #evo_operator = aux_ops[0]
        #if evo_operator is None:
        #    raise AquaError("EnergyInput, invalid aux op.")

        dynamics_params = params.get(Pluggable.SECTION_KEY_ALGORITHM)
        operator_mode = dynamics_params.get(SHOR.PROP_OPERATOR_MODE)
        num_to_eval = dynamics_params.get(SHOR.PROP_NUM_EVAL)
        num_A = dynamics_params.get(SHOR.PROP_NUM_A)
        #expansion_mode = dynamics_params.get(SHOR.PROP_EXPANSION_MODE)
        #expansion_order = dynamics_params.get(SHOR.PROP_EXPANSION_ORDER)

        # Set up initial state, we need to add computed num qubits to params
        initial_state_params = params.get(Pluggable.SECTION_KEY_INITIAL_STATE)
        initial_state_params['num_qubits'] = 6
        initial_state = get_pluggable_class(PluggableType.INITIAL_STATE,
                                            initial_state_params['name']).init_params(params)

        #return cls(operator, initial_state, evo_operator, operator_mode, evo_time, num_time_slices,
        #           expansion_mode=expansion_mode,
        #           expansion_order=expansion_order)
        return cls( initial_state,operator_mode, num_to_eval, num_A)

    # qc = quantum circuit, qr = quantum register, cr = classical register, a = 2, 7, 8, 11 or 13
    def circuit_amod15(self,qc,qr,cr,a):
        if a == 2:
            qc.cswap(qr[4],qr[3],qr[2])
            qc.cswap(qr[4],qr[2],qr[1])
            qc.cswap(qr[4],qr[1],qr[0])
        elif a == 7:
            qc.cswap(qr[4],qr[1],qr[0])
            qc.cswap(qr[4],qr[2],qr[1])
            qc.cswap(qr[4],qr[3],qr[2])
            qc.cx(qr[4],qr[3])
            qc.cx(qr[4],qr[2])
            qc.cx(qr[4],qr[1])
            qc.cx(qr[4],qr[0])
        elif a == 8:
            qc.cswap(qr[4],qr[1],qr[0])
            qc.cswap(qr[4],qr[2],qr[1])
            qc.cswap(qr[4],qr[3],qr[2])
        elif a == 11: # this is included for completeness
            qc.cswap(qr[4],qr[2],qr[0])
            qc.cswap(qr[4],qr[3],qr[1])
            qc.cx(qr[4],qr[3])
            qc.cx(qr[4],qr[2])
            qc.cx(qr[4],qr[1])
            qc.cx(qr[4],qr[0])
        elif a == 13:
            qc.cswap(qr[4],qr[3],qr[2])
            qc.cswap(qr[4],qr[2],qr[1])
            qc.cswap(qr[4],qr[1],qr[0])
            qc.cx(qr[4],qr[3])
            qc.cx(qr[4],qr[2])
            qc.cx(qr[4],qr[1])
            qc.cx(qr[4],qr[0])
        return qc
 
    def circuit_11period15(self,qc,qr,cr):
       # Initialize q[0] to |1> 
       qc.x(qr[0])

       # Apply a**4 mod 15
       qc.h(qr[4])
       #   controlled identity on the remaining 4 qubits, which is equivalent to doing nothing
       qc.h(qr[4])
       #   measure
       qc.measure(qr[4],cr[0])
       #   reinitialise q[4] to |0>
       qc.reset(qr[4])

       # Apply a**2 mod 15
       qc.h(qr[4])
       #   controlled identity on the remaining 4 qubits, which is equivalent to doing nothing
       #   feed forward
       qc.u1(math.pi/2.,qr[4]).c_if(cr, 1)
       qc.h(qr[4])
       #   measure
       qc.measure(qr[4],cr[1])
       #   reinitialise q[4] to |0>
       qc.reset(qr[4])

       # Apply 11 mod 15
       qc.h(qr[4])
       #   controlled unitary.
       qc.cx(qr[4],qr[3])
       qc.cx(qr[4],qr[1])
       #   feed forward
       qc.u1(3.*math.pi/4.,qr[4]).c_if(cr, 3)
       qc.u1(math.pi/2.,qr[4]).c_if(cr, 2)
       qc.u1(math.pi/4.,qr[4]).c_if(cr, 1)
       qc.h(qr[4])
       #   measure
       qc.measure(qr[4],cr[2])

       return qc

    # qc = quantum circuit, qr = quantum register, cr = classical register, a = 2, 7, 8, 11 or 13
    def circuit_aperiod15(self,qc,qr,cr,a):
       if a == 11:
           self.circuit_11period15(qc,qr,cr)
           return qc
    
       # Initialize q[0] to |1> 
       qc.x(qr[0])
   
       # Apply a**4 mod 15
       qc.h(qr[4])
       #   controlled identity on the remaining 4 qubits, which is equivalent to doing nothing
       qc.h(qr[4])
       #   measure
       qc.measure(qr[4],cr[0])
       #   reinitialise q[4] to |0>
       qc.reset(qr[4])

       # Apply a**2 mod 15
       qc.h(qr[4])
       #   controlled unitary
       qc.cx(qr[4],qr[2])
       qc.cx(qr[4],qr[0])
       #   feed forward
       qc.u1(math.pi/2.,qr[4]).c_if(cr, 1)
       qc.h(qr[4])
       #   measure
       qc.measure(qr[4],cr[1])
       #   reinitialise q[4] to |0>
       qc.reset(qr[4])

       # Apply a mod 15
       qc.h(qr[4])
       #   controlled unitary.
       self.circuit_amod15(qc,qr,cr,a)
       #   feed forward
       qc.u1(3.*math.pi/4.,qr[4]).c_if(cr, 3)
       qc.u1(math.pi/2.,qr[4]).c_if(cr, 2)
       qc.u1(math.pi/4.,qr[4]).c_if(cr, 1)
       qc.h(qr[4])
       #   measure
       qc.measure(qr[4],cr[2])
       
       return qc

    def construct_circuit(self):
        """
        Construct the circuit.

        Returns:
            QuantumCircuit: the circuit.
        """
        #quantum_registers = QuantumRegister(self._operator.num_qubits, name='q')
        #quantum_registers = QuantumRegister(6, name='q')
        q = QuantumRegister(7, 'q')
        c = ClassicalRegister(7, 'c')
        #qc = self._initial_state.construct_circuit('circuit', quantum_registers)
        qc = QuantumCircuit(q,c) #to be update
        qc = self.circuit_aperiod15(qc,q,c,self._num_a)

        #qc += self._evo_operator.evolve(
        #    None,
        #    self._evo_time,
        #    'circuit',
        #    self._num_time_slices,
        #    quantum_registers=quantum_registers,
        #    expansion_mode=self._expansion_mode,
        #    expansion_order=self._expansion_order,
        #)

        return qc

    def calc(self,sim_data):
        
        period=len(sim_data.values())
        first=np.gcd(15, self._num_a**(int(period/2))-1)
        second= np.gcd(15, self._num_a**(int(period/2))+1)

        return first, second

    def _run(self):
        qc = self.construct_circuit()
        #qc_with_op = self._operator.construct_evaluation_circuit(
        #    self._operator_mode, qc, self._quantum_instance.backend
        #)
        #result = self._quantum_instance.execute(qc)
        #self._ret['avg'], self._ret['std_dev'] = self._operator.evaluate_with_result(
        #    self._operator_mode, qc_with_op, self._quantum_instance.backend, result
        #)

        backend = BasicAer.get_backend('qasm_simulator')
        sim_job = execute([qc], backend)
        #qc.draw(output='mpl')
        sim_result = sim_job.result()
        print(sim_result)
        sim_data = sim_result.get_counts(qc) 
        print()        
        print("Frequency results:")        
        print(sim_data)
        #plot_histogram(sim_data)

        first,second=self.calc(sim_data)
        print()
        print("The two factors are:" , first, second)
        return self._ret
