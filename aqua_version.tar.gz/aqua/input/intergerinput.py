# -*- coding: utf-8 -*-

# Copyright 2018 IBM.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# =============================================================================

from qiskit.aqua import AquaError, Operator
from qiskit.aqua.input import AlgorithmInput


class integerinput(AlgorithmInput):

    #PROP_KEY_QUBITOP = 'qubit_op'
    #PROP_KEY_AUXOPS = 'aux_ops'

    CONFIGURATION = {
        'name': 'intergerinput',
        'description': 'interger problem input',
        'input_schema': {
            '$schema': 'http://json-schema.org/schema#',
            'id': 'integer_state_schema',
            'type': 'object',
            'properties': {
     #           PROP_KEY_QUBITOP: {
     #               'type': 'object',
     #               'default': {}
     #           },
     #           PROP_KEY_AUXOPS: {
     #               'type': ['array', 'null'],
     #               'default': None
     #           }
            },
            'additionalProperties': False
        },
        'problems': ['shor']
    }

    def __init__(self):
        self.validate(locals())
        super().__init__()

    def validate(self, args_dict):
        params = {}
        super().validate(params)

    def to_params(self):
        params = {}
        return params

    @classmethod
    def from_params(cls, params):
        #if 'training_dataset' not in params:
        #    raise AquaError("training_dataset is required.")
        #training_dataset = params['training_dataset']
        #test_dataset = params['test_dataset']
        #datapoints = params['datapoints']
        return cls()
